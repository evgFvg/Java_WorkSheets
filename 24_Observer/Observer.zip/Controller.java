class Controller<V> {
    private final Dispatcher<V> dispatcher = new Dispatcher<>();
    private final DataModel<V> dataBase;
    public Controller(DataModel<V> dataBase) {
        this.dataBase = dataBase;
    }
    public void addData(V msg) {
        dataBase.addToDataBase(msg);
        dispatcher.notifyAll(msg);
    }
    public void addSubscriber(Dispatcher.Callback<V> newSubscriber) {
        dispatcher.addCallback(newSubscriber);
    }
    public void removeSubscriber(Dispatcher.Callback<V> subscriber) {
        dispatcher.removeCallback(subscriber);
    }
    public void removeAll() {
        dispatcher.stop();
    }
}