import java.util.ArrayList;
import java.util.List;

class DataModel<T> {
    private List<T> dataBase = new ArrayList<>();
    public void addToDataBase(T t) {
        dataBase.add(t);
    }

}