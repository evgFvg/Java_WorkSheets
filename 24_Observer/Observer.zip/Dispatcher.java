import java.util.ArrayList;
import java.util.List;

public class Dispatcher<T> {
    private final List<Callback<T>> callbackList = new ArrayList<>();
    public void addCallback(Callback<T> callback) {
        callback.dispatcher = this;
        callbackList.add(callback);
    }

    public boolean removeCallback(Callback<T> callback) {
        return callbackList.remove(callback);
    }

    public void notifyAll(T msg) {
        List<Callback<T>> newList = new ArrayList<>(callbackList);
        newList.forEach(c->c.update(msg));
    }
    public void stop() {
        callbackList.forEach(Callback::updateOnDeath);
        callbackList.clear();
    }

    public static abstract class Callback<V>{
        private Dispatcher<V> dispatcher = null;
        public abstract void update(V msg);
        public abstract void updateOnDeath();
        public final void stop() {
            dispatcher.removeCallback(this);
        }
    }
}