/************************************
 *   Observer implementation:       *
 *                                  *
 *  Developer: Evgenii Feigin       *
 *  Reviewer: Aviv                  *
 *  Date: 31.07.2023                *
 ************************************/
public class Main {
    public static void main(String[] args) {
        DataModel<String> db = new DataModel<>();
        Controller<String> controller = new Controller<>(db);

        IphoneWaiter<String> user1 = new IphoneWaiter<>(SubscribeTasks::ifIphoneArrived, SubscribeTasks::unsubscribe);
        AndroidWaiter<String> user2 = new AndroidWaiter<>(SubscribeTasks::ifAndroidArrived, SubscribeTasks::unsubscribe);
        NewYorkTimesWaiter<String> user3 = new NewYorkTimesWaiter<>(SubscribeTasks::ifNewYorkTimesArrived, SubscribeTasks::unsubscribe);

        XiaomiWaiter<String> user4 = new XiaomiWaiter<>(null, SubscribeTasks::unsubscribe);
        FriendBringsOneFriend<String> user5 = new FriendBringsOneFriend<>(null, SubscribeTasks::unsubscribe, controller);

        controller.addSubscriber(user1);
        controller.addSubscriber(user2);
        controller.addSubscriber(user3);
        controller.addSubscriber(user4);
        controller.addSubscriber(user5);

        controller.addData("Iphone arrived");
        controller.addData("Android arrived");
        controller.addData("NewYorkTimes arrived");

        controller.addData("Samsung arrived");  //remove while broadcast
        controller.addData("5000 for a new student"); //add one subscriber while broadcast
        controller.removeAll();  // remove all while broadcast
    }
}