import java.util.function.Consumer;

class IphoneWaiter<V> extends CallbackKeeper<V>{
    IphoneWaiter(Consumer<V> updateFunc, Runnable onDeathFunc) {
        super(updateFunc, onDeathFunc);
    }
    IphoneWaiter() {
        super(System.out::println, ()->{
            System.out.println("I am unsubscribed");
        });
    }
}
class AndroidWaiter<V> extends CallbackKeeper<V>{
    AndroidWaiter(Consumer<V> updateFunc, Runnable onDeathFunc) {
        super(updateFunc, onDeathFunc);
    }
}
class NewYorkTimesWaiter<V> extends CallbackKeeper<V>{
    NewYorkTimesWaiter(Consumer<V> updateFunc, Runnable onDeathFunc) {
        super(updateFunc, onDeathFunc);
    }
}

class FriendBringsOneFriend<V> extends CallbackKeeper<V>{
    private final Controller<V> controller;
    FriendBringsOneFriend(Consumer<V> updateFunc, Runnable onDeathFunc, Controller<V> controller) {
        super(updateFunc, onDeathFunc);
        this.controller = controller;
    }

    @Override
    public void update(V msg) {
        if(msg.equals("5000 for a new student")) {
            System.out.println("Subscriber B is going to add a new Subscriber");
            controller.addSubscriber(new IphoneWaiter<>());
            System.out.println("new subscriber is added");
        }
    }
}

class XiaomiWaiter<V> extends CallbackKeeper<V>{
    private static int msgCounter = 0;

    XiaomiWaiter(Consumer<V> updateFunc, Runnable onDeathFunc) {
        super(updateFunc, onDeathFunc);
    }

    @Override
    public void update(V msg) {
        ++msgCounter;
        if(!msg.equals("Xiaomi arrived") && msgCounter == 3) {
            System.out.println("Xiaomi waiter - I have waited enough, unsubscribing...");
            this.stop();
        }
    }
}

class SubscribeTasks {

    public static void ifIphoneArrived(String msg) {
        if(msg.equals("Iphone arrived")) {
            System.out.println("Subscriber X is going to get his iphone");
        } else if(msg.equals("del")){
            System.out.println("Subscriber X keep waiting for the next Iphone arrival");
        }
    }

    public static void ifAndroidArrived(String msg) {
        if(msg.equals("Android arrived")) {
            System.out.println("Subscriber Y is going to get his Android");
        } else {
            System.out.println("Subscriber Y keep waiting for the next Android arrival");
        }
    }

    public static void ifNewYorkTimesArrived(String msg) {
        if(msg.equals("NewYorkTimes arrived")) {
            System.out.println("Subscriber W is going to get his newspaper");
        } else {
            System.out.println("Subscriber W keep waiting for the next newspaper arrival");
        }
    }

    public static void addNewSubscriberWhileBroadcast(String msg) {
        if(msg.equals("5000 for a new student")) {
            System.out.println("Subscriber B is going to add a new Subscriber");

        } else {
            System.out.println("Subscriber W keep waiting for the next newspaper arrival");
        }
    }


    public static void unsubscribe () {
        System.out.println("Subscriber X unsubscribed");
    }
}

class CallbackKeeper<V> extends Dispatcher.Callback<V> {
    private final Consumer<V> updateFunc;
    private final Runnable onDeathFunc;

    CallbackKeeper(Consumer<V> updateFunc, Runnable onDeathFunc) {
        this.updateFunc = updateFunc;
        this.onDeathFunc = onDeathFunc;
    }

    @Override
    public void update(V msg) {
        updateFunc.accept(msg);
    }

    @Override
    public void updateOnDeath() {
        onDeathFunc.run();
    }
}
