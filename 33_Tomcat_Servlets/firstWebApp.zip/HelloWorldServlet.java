
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/HelloWorld")
public class HelloWorldServlet extends HttpServlet{
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // Retrieve the 'name' parameter from the URL
        String name = request.getParameter("name");
        // Set the content type and write the response
        response.setContentType("text/html");
        response.getWriter().println("Hello world " + name);
    }
}
/*
  1)  Compile the Servlet:
        Compile the servlet using the javac command.
        Make sure you have the servlet API JAR file in your classpath.
        The servlet API JAR file is typically located in the Tomcat lib directory.
 */
 /*
 javac -classpath /path/to/servlet-api.jar HelloWorldServlet.java
/*
2)
Create a WAR File:

To deploy the servlet to Tomcat, package it into a WAR (Web Application Archive) file.
Create a directory structure like this:
*/
/*
firstWebApp/
├── WEB-INF/
│   └── classes/
│       └── HelloWorldServlet.class
└── web.xml
  */

/*
3)Create a web.xml file in the WEB-INF directory:

<?xml version="1.0" encoding="UTF-8"?>
<web-app xmlns="http://xmlns.jcp.org/xml/ns/javaee"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://xmlns.jcp.org/xml/ns/javaee http://xmlns.jcp.org/xml/ns/javaee/web-app_3_1.xsd"
         version="3.1">
</web-app>
 */

/*
4) Then, create a WAR file from the firstWebApp directory:

bash

jar -cvf firstWebApp.war -C firstWebApp .
*/

/*
5)Deploy the WAR File:

Copy the firstWebApp.war file to Tomcat's webapps directory.
You can do this manually or by using the command line:

bash

cp firstWebApp.war /path/to/tomcat/webapps/
 */

/*
6)Start Tomcat:

If Tomcat is not already running, start it by executing the following command:

bash

/path/to/tomcat/bin/startup.sh
 */

/*
7)Access the Servlet:

Once Tomcat is running, you can access your servlet using a URL like:

bash

http://localhost:8080/firstWebApp/HelloWorld?name=john
 */

